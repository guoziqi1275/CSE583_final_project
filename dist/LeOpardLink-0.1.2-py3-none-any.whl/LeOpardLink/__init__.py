"""
LeOpardLink

A package to generate all possible graphs for wildlife individual identification, and visualize them.
"""

__version__ = "0.1.2"
__author__ = 'Courtney Allen, Ziqi Guo, Guy Bennevat Haninovich, Jiangyue Wang'