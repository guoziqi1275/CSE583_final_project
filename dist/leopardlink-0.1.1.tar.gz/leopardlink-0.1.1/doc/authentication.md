# 1 Check is the adjacency matrix is correct
## Squared and symmetric matrix

# 2 Information embedded in pictures (GPS information of rare animals)
