# Progress for this period

1. Data storage structure figured out (adjacency matrix and list)

2. Data input check & test almost done

3. Simulation dataset and real-world dataset done.

4. Visualization method settled.

# What should be finished next period

1. Organize code into Python package structure

2. Link our repo to streamlit - Get the web app working!

# Challenges

1. Functions for achieve transitivity and list all possible graphs (not hard to write, but very hard to write a time efficient one). If we cannot write a time efficient one, we can write the complicated one and get it working on our small dataset.
